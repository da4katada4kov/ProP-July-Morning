﻿namespace Cashapp
{
    partial class ShopApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ShopApp));
            this.orderlist = new System.Windows.Forms.ListBox();
            this.btnCheckout = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.btnCola = new System.Windows.Forms.Button();
            this.btnSprite = new System.Windows.Forms.Button();
            this.btnSchweppes = new System.Windows.Forms.Button();
            this.btnRedBull = new System.Windows.Forms.Button();
            this.btnBavaria = new System.Windows.Forms.Button();
            this.btnJupiler = new System.Windows.Forms.Button();
            this.btnHeineken = new System.Windows.Forms.Button();
            this.btnCorona = new System.Windows.Forms.Button();
            this.btnKamenitza = new System.Windows.Forms.Button();
            this.btnOJ = new System.Windows.Forms.Button();
            this.btnSmirnoff = new System.Windows.Forms.Button();
            this.btnJD = new System.Windows.Forms.Button();
            this.btnHavana = new System.Windows.Forms.Button();
            this.btnJC = new System.Windows.Forms.Button();
            this.btnCalcMinus = new System.Windows.Forms.Button();
            this.btnCalcPlus = new System.Windows.Forms.Button();
            this.btnPizza = new System.Windows.Forms.Button();
            this.btnDoner = new System.Windows.Forms.Button();
            this.btnFries = new System.Windows.Forms.Button();
            this.btnBurger = new System.Windows.Forms.Button();
            this.btnHotdog = new System.Windows.Forms.Button();
            this.btnNuts = new System.Windows.Forms.Button();
            this.btnFanta = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnFinlandia = new System.Windows.Forms.Button();
            this.buttonLJ = new System.Windows.Forms.Button();
            this.buttonCJ = new System.Windows.Forms.Button();
            this.buttonLimeJ = new System.Windows.Forms.Button();
            this.toolTipOJ = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipLJ = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipCJ = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipLimeJ = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipRum = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipWhiskey = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipTequila = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipSmirnoff = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipFinlandia = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipPizza = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipDonerKebab = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipBurger = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipHotDog = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipNuts = new System.Windows.Forms.ToolTip(this.components);
            this.toolTipFries = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // orderlist
            // 
            this.orderlist.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orderlist.FormattingEnabled = true;
            this.orderlist.ItemHeight = 20;
            this.orderlist.Location = new System.Drawing.Point(812, 36);
            this.orderlist.Name = "orderlist";
            this.orderlist.Size = new System.Drawing.Size(309, 404);
            this.orderlist.TabIndex = 0;
            // 
            // btnCheckout
            // 
            this.btnCheckout.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckout.Location = new System.Drawing.Point(812, 502);
            this.btnCheckout.Name = "btnCheckout";
            this.btnCheckout.Size = new System.Drawing.Size(309, 69);
            this.btnCheckout.TabIndex = 1;
            this.btnCheckout.Text = "Checkout";
            this.btnCheckout.UseVisualStyleBackColor = true;
            this.btnCheckout.Click += new System.EventHandler(this.btnCheckout_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(924, 452);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 38);
            this.label1.TabIndex = 2;
            this.label1.Text = "Total:";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.BackColor = System.Drawing.Color.Transparent;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.ForeColor = System.Drawing.Color.White;
            this.lblTotal.Location = new System.Drawing.Point(1028, 452);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(64, 39);
            this.lblTotal.TabIndex = 3;
            this.lblTotal.Text = "0 €";
            // 
            // btnCola
            // 
            this.btnCola.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCola.BackgroundImage")));
            this.btnCola.Location = new System.Drawing.Point(12, 12);
            this.btnCola.Name = "btnCola";
            this.btnCola.Size = new System.Drawing.Size(154, 107);
            this.btnCola.TabIndex = 4;
            this.btnCola.UseVisualStyleBackColor = true;
            this.btnCola.Click += new System.EventHandler(this.btnCola_Click);
            // 
            // btnSprite
            // 
            this.btnSprite.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSprite.BackgroundImage")));
            this.btnSprite.Location = new System.Drawing.Point(332, 12);
            this.btnSprite.Name = "btnSprite";
            this.btnSprite.Size = new System.Drawing.Size(154, 107);
            this.btnSprite.TabIndex = 6;
            this.btnSprite.UseVisualStyleBackColor = true;
            this.btnSprite.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnSchweppes
            // 
            this.btnSchweppes.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSchweppes.BackgroundImage")));
            this.btnSchweppes.Location = new System.Drawing.Point(492, 12);
            this.btnSchweppes.Name = "btnSchweppes";
            this.btnSchweppes.Size = new System.Drawing.Size(154, 107);
            this.btnSchweppes.TabIndex = 7;
            this.btnSchweppes.UseVisualStyleBackColor = true;
            this.btnSchweppes.Click += new System.EventHandler(this.btnSchweppes_Click);
            // 
            // btnRedBull
            // 
            this.btnRedBull.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnRedBull.BackgroundImage")));
            this.btnRedBull.Location = new System.Drawing.Point(652, 12);
            this.btnRedBull.Name = "btnRedBull";
            this.btnRedBull.Size = new System.Drawing.Size(154, 107);
            this.btnRedBull.TabIndex = 8;
            this.btnRedBull.UseVisualStyleBackColor = true;
            this.btnRedBull.Click += new System.EventHandler(this.btnRedBull_Click);
            // 
            // btnBavaria
            // 
            this.btnBavaria.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBavaria.BackgroundImage")));
            this.btnBavaria.Location = new System.Drawing.Point(12, 125);
            this.btnBavaria.Name = "btnBavaria";
            this.btnBavaria.Size = new System.Drawing.Size(154, 107);
            this.btnBavaria.TabIndex = 9;
            this.btnBavaria.UseVisualStyleBackColor = true;
            this.btnBavaria.Click += new System.EventHandler(this.button6_Click);
            // 
            // btnJupiler
            // 
            this.btnJupiler.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnJupiler.BackgroundImage")));
            this.btnJupiler.Location = new System.Drawing.Point(172, 125);
            this.btnJupiler.Name = "btnJupiler";
            this.btnJupiler.Size = new System.Drawing.Size(154, 107);
            this.btnJupiler.TabIndex = 10;
            this.btnJupiler.UseVisualStyleBackColor = true;
            this.btnJupiler.Click += new System.EventHandler(this.button7_Click);
            // 
            // btnHeineken
            // 
            this.btnHeineken.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnHeineken.BackgroundImage")));
            this.btnHeineken.Location = new System.Drawing.Point(332, 125);
            this.btnHeineken.Name = "btnHeineken";
            this.btnHeineken.Size = new System.Drawing.Size(154, 107);
            this.btnHeineken.TabIndex = 11;
            this.btnHeineken.UseVisualStyleBackColor = true;
            this.btnHeineken.Click += new System.EventHandler(this.button8_Click);
            // 
            // btnCorona
            // 
            this.btnCorona.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCorona.BackgroundImage")));
            this.btnCorona.Location = new System.Drawing.Point(492, 125);
            this.btnCorona.Name = "btnCorona";
            this.btnCorona.Size = new System.Drawing.Size(154, 107);
            this.btnCorona.TabIndex = 12;
            this.btnCorona.UseVisualStyleBackColor = true;
            this.btnCorona.Click += new System.EventHandler(this.button9_Click);
            // 
            // btnKamenitza
            // 
            this.btnKamenitza.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnKamenitza.BackgroundImage")));
            this.btnKamenitza.Location = new System.Drawing.Point(652, 125);
            this.btnKamenitza.Name = "btnKamenitza";
            this.btnKamenitza.Size = new System.Drawing.Size(154, 107);
            this.btnKamenitza.TabIndex = 13;
            this.btnKamenitza.UseVisualStyleBackColor = true;
            this.btnKamenitza.Click += new System.EventHandler(this.button10_Click);
            // 
            // btnOJ
            // 
            this.btnOJ.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnOJ.BackgroundImage")));
            this.btnOJ.Location = new System.Drawing.Point(492, 351);
            this.btnOJ.Name = "btnOJ";
            this.btnOJ.Size = new System.Drawing.Size(154, 107);
            this.btnOJ.TabIndex = 14;
            this.btnOJ.UseVisualStyleBackColor = true;
            this.btnOJ.Click += new System.EventHandler(this.button11_Click);
            // 
            // btnSmirnoff
            // 
            this.btnSmirnoff.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSmirnoff.BackgroundImage")));
            this.btnSmirnoff.Location = new System.Drawing.Point(172, 238);
            this.btnSmirnoff.Name = "btnSmirnoff";
            this.btnSmirnoff.Size = new System.Drawing.Size(154, 107);
            this.btnSmirnoff.TabIndex = 15;
            this.btnSmirnoff.UseVisualStyleBackColor = true;
            this.btnSmirnoff.Click += new System.EventHandler(this.btnSmirnoff_Click);
            // 
            // btnJD
            // 
            this.btnJD.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnJD.BackgroundImage")));
            this.btnJD.Location = new System.Drawing.Point(332, 238);
            this.btnJD.Name = "btnJD";
            this.btnJD.Size = new System.Drawing.Size(154, 107);
            this.btnJD.TabIndex = 16;
            this.btnJD.UseVisualStyleBackColor = true;
            this.btnJD.Click += new System.EventHandler(this.button13_Click);
            // 
            // btnHavana
            // 
            this.btnHavana.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnHavana.BackgroundImage")));
            this.btnHavana.Location = new System.Drawing.Point(492, 238);
            this.btnHavana.Name = "btnHavana";
            this.btnHavana.Size = new System.Drawing.Size(154, 107);
            this.btnHavana.TabIndex = 17;
            this.btnHavana.UseVisualStyleBackColor = true;
            this.btnHavana.Click += new System.EventHandler(this.button14_Click);
            // 
            // btnJC
            // 
            this.btnJC.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnJC.BackgroundImage")));
            this.btnJC.Location = new System.Drawing.Point(652, 238);
            this.btnJC.Name = "btnJC";
            this.btnJC.Size = new System.Drawing.Size(154, 107);
            this.btnJC.TabIndex = 18;
            this.btnJC.UseVisualStyleBackColor = true;
            this.btnJC.Click += new System.EventHandler(this.button15_Click);
            // 
            // btnCalcMinus
            // 
            this.btnCalcMinus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnCalcMinus.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcMinus.Location = new System.Drawing.Point(812, 446);
            this.btnCalcMinus.Name = "btnCalcMinus";
            this.btnCalcMinus.Size = new System.Drawing.Size(50, 50);
            this.btnCalcMinus.TabIndex = 28;
            this.btnCalcMinus.Text = "-";
            this.btnCalcMinus.UseVisualStyleBackColor = false;
            this.btnCalcMinus.Click += new System.EventHandler(this.btnCalcMinus_Click);
            // 
            // btnCalcPlus
            // 
            this.btnCalcPlus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnCalcPlus.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcPlus.Location = new System.Drawing.Point(868, 446);
            this.btnCalcPlus.Name = "btnCalcPlus";
            this.btnCalcPlus.Size = new System.Drawing.Size(50, 50);
            this.btnCalcPlus.TabIndex = 30;
            this.btnCalcPlus.Text = "+";
            this.btnCalcPlus.UseVisualStyleBackColor = false;
            this.btnCalcPlus.Click += new System.EventHandler(this.btnCalcPlus_Click);
            // 
            // btnPizza
            // 
            this.btnPizza.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPizza.BackgroundImage")));
            this.btnPizza.Location = new System.Drawing.Point(12, 351);
            this.btnPizza.Name = "btnPizza";
            this.btnPizza.Size = new System.Drawing.Size(154, 107);
            this.btnPizza.TabIndex = 31;
            this.btnPizza.UseVisualStyleBackColor = true;
            this.btnPizza.Click += new System.EventHandler(this.button16_Click);
            // 
            // btnDoner
            // 
            this.btnDoner.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDoner.BackgroundImage")));
            this.btnDoner.Location = new System.Drawing.Point(172, 351);
            this.btnDoner.Name = "btnDoner";
            this.btnDoner.Size = new System.Drawing.Size(154, 107);
            this.btnDoner.TabIndex = 32;
            this.btnDoner.UseVisualStyleBackColor = true;
            this.btnDoner.Click += new System.EventHandler(this.button17_Click);
            // 
            // btnFries
            // 
            this.btnFries.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnFries.BackgroundImage")));
            this.btnFries.Location = new System.Drawing.Point(332, 351);
            this.btnFries.Name = "btnFries";
            this.btnFries.Size = new System.Drawing.Size(154, 107);
            this.btnFries.TabIndex = 33;
            this.btnFries.UseVisualStyleBackColor = true;
            this.btnFries.Click += new System.EventHandler(this.button18_Click);
            // 
            // btnBurger
            // 
            this.btnBurger.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBurger.BackgroundImage")));
            this.btnBurger.Location = new System.Drawing.Point(12, 464);
            this.btnBurger.Name = "btnBurger";
            this.btnBurger.Size = new System.Drawing.Size(154, 107);
            this.btnBurger.TabIndex = 34;
            this.btnBurger.UseVisualStyleBackColor = true;
            this.btnBurger.Click += new System.EventHandler(this.button19_Click);
            // 
            // btnHotdog
            // 
            this.btnHotdog.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnHotdog.BackgroundImage")));
            this.btnHotdog.Location = new System.Drawing.Point(172, 464);
            this.btnHotdog.Name = "btnHotdog";
            this.btnHotdog.Size = new System.Drawing.Size(154, 107);
            this.btnHotdog.TabIndex = 35;
            this.btnHotdog.UseVisualStyleBackColor = true;
            this.btnHotdog.Click += new System.EventHandler(this.button20_Click);
            // 
            // btnNuts
            // 
            this.btnNuts.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnNuts.BackgroundImage")));
            this.btnNuts.Location = new System.Drawing.Point(332, 464);
            this.btnNuts.Name = "btnNuts";
            this.btnNuts.Size = new System.Drawing.Size(154, 107);
            this.btnNuts.TabIndex = 36;
            this.btnNuts.UseVisualStyleBackColor = true;
            this.btnNuts.Click += new System.EventHandler(this.button21_Click);
            // 
            // btnFanta
            // 
            this.btnFanta.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnFanta.BackgroundImage")));
            this.btnFanta.Location = new System.Drawing.Point(172, 12);
            this.btnFanta.Name = "btnFanta";
            this.btnFanta.Size = new System.Drawing.Size(154, 107);
            this.btnFanta.TabIndex = 5;
            this.btnFanta.UseVisualStyleBackColor = true;
            this.btnFanta.Click += new System.EventHandler(this.btnFanta_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(812, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 13);
            this.label2.TabIndex = 37;
            this.label2.Text = "*Select product from list";
            // 
            // btnFinlandia
            // 
            this.btnFinlandia.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnFinlandia.BackgroundImage")));
            this.btnFinlandia.Location = new System.Drawing.Point(12, 238);
            this.btnFinlandia.Name = "btnFinlandia";
            this.btnFinlandia.Size = new System.Drawing.Size(154, 107);
            this.btnFinlandia.TabIndex = 38;
            this.btnFinlandia.UseVisualStyleBackColor = true;
            // 
            // buttonLJ
            // 
            this.buttonLJ.BackColor = System.Drawing.SystemColors.Control;
            this.buttonLJ.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonLJ.BackgroundImage")));
            this.buttonLJ.Location = new System.Drawing.Point(652, 351);
            this.buttonLJ.Name = "buttonLJ";
            this.buttonLJ.Size = new System.Drawing.Size(154, 107);
            this.buttonLJ.TabIndex = 39;
            this.buttonLJ.UseVisualStyleBackColor = false;
            this.buttonLJ.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonCJ
            // 
            this.buttonCJ.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonCJ.BackgroundImage")));
            this.buttonCJ.Location = new System.Drawing.Point(492, 464);
            this.buttonCJ.Name = "buttonCJ";
            this.buttonCJ.Size = new System.Drawing.Size(154, 107);
            this.buttonCJ.TabIndex = 40;
            this.buttonCJ.UseVisualStyleBackColor = true;
            this.buttonCJ.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonLimeJ
            // 
            this.buttonLimeJ.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonLimeJ.BackgroundImage")));
            this.buttonLimeJ.Location = new System.Drawing.Point(652, 464);
            this.buttonLimeJ.Name = "buttonLimeJ";
            this.buttonLimeJ.Size = new System.Drawing.Size(154, 107);
            this.buttonLimeJ.TabIndex = 41;
            this.buttonLimeJ.UseVisualStyleBackColor = true;
            this.buttonLimeJ.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // ShopApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1133, 587);
            this.Controls.Add(this.buttonLimeJ);
            this.Controls.Add(this.buttonCJ);
            this.Controls.Add(this.buttonLJ);
            this.Controls.Add(this.btnFinlandia);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnNuts);
            this.Controls.Add(this.btnHotdog);
            this.Controls.Add(this.btnBurger);
            this.Controls.Add(this.btnFries);
            this.Controls.Add(this.btnDoner);
            this.Controls.Add(this.btnPizza);
            this.Controls.Add(this.btnCalcPlus);
            this.Controls.Add(this.btnCalcMinus);
            this.Controls.Add(this.btnJC);
            this.Controls.Add(this.btnHavana);
            this.Controls.Add(this.btnJD);
            this.Controls.Add(this.btnSmirnoff);
            this.Controls.Add(this.btnOJ);
            this.Controls.Add(this.btnKamenitza);
            this.Controls.Add(this.btnCorona);
            this.Controls.Add(this.btnHeineken);
            this.Controls.Add(this.btnJupiler);
            this.Controls.Add(this.btnBavaria);
            this.Controls.Add(this.btnRedBull);
            this.Controls.Add(this.btnSchweppes);
            this.Controls.Add(this.btnSprite);
            this.Controls.Add(this.btnFanta);
            this.Controls.Add(this.btnCola);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCheckout);
            this.Controls.Add(this.orderlist);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ShopApp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "July Morning Shop Application";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox orderlist;
        private System.Windows.Forms.Button btnCheckout;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button btnCola;
        private System.Windows.Forms.Button btnSprite;
        private System.Windows.Forms.Button btnSchweppes;
        private System.Windows.Forms.Button btnRedBull;
        private System.Windows.Forms.Button btnBavaria;
        private System.Windows.Forms.Button btnJupiler;
        private System.Windows.Forms.Button btnHeineken;
        private System.Windows.Forms.Button btnCorona;
        private System.Windows.Forms.Button btnKamenitza;
        private System.Windows.Forms.Button btnOJ;
        private System.Windows.Forms.Button btnSmirnoff;
        private System.Windows.Forms.Button btnJD;
        private System.Windows.Forms.Button btnHavana;
        private System.Windows.Forms.Button btnJC;
        private System.Windows.Forms.Button btnCalcMinus;
        private System.Windows.Forms.Button btnCalcPlus;
        private System.Windows.Forms.Button btnPizza;
        private System.Windows.Forms.Button btnDoner;
        private System.Windows.Forms.Button btnFries;
        private System.Windows.Forms.Button btnBurger;
        private System.Windows.Forms.Button btnHotdog;
        private System.Windows.Forms.Button btnNuts;
        private System.Windows.Forms.Button btnFanta;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnFinlandia;
        private System.Windows.Forms.Button buttonLJ;
        private System.Windows.Forms.Button buttonCJ;
        private System.Windows.Forms.Button buttonLimeJ;
        private System.Windows.Forms.ToolTip toolTipOJ;
        private System.Windows.Forms.ToolTip toolTipLJ;
        private System.Windows.Forms.ToolTip toolTipCJ;
        private System.Windows.Forms.ToolTip toolTipLimeJ;
        private System.Windows.Forms.ToolTip toolTipRum;
        private System.Windows.Forms.ToolTip toolTipWhiskey;
        private System.Windows.Forms.ToolTip toolTipTequila;
        private System.Windows.Forms.ToolTip toolTipSmirnoff;
        private System.Windows.Forms.ToolTip toolTipFinlandia;
        private System.Windows.Forms.ToolTip toolTipPizza;
        private System.Windows.Forms.ToolTip toolTipDonerKebab;
        private System.Windows.Forms.ToolTip toolTipBurger;
        private System.Windows.Forms.ToolTip toolTipHotDog;
        private System.Windows.Forms.ToolTip toolTipNuts;
        private System.Windows.Forms.ToolTip toolTipFries;
    }
}

